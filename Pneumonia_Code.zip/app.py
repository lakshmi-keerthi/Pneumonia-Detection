from flask import Flask, render_template, request
from PIL import Image
import io
import numpy as np
import tensorflow as tf

app = Flask(__name__)

# Load the trained CNN model
model = tf.keras.models.load_model('CNN_model.h5')

# Define a function to preprocess the uploaded image
def preprocess_image(image):
    img = image.resize((224, 224)) # Resize the image to the input size of the model
    img = np.array(img)
    img = img / 255.0 # Normalize pixel values to the range [0, 1]
    img = np.expand_dims(img, axis=0) # Add a batch dimension
    return img

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/classify', methods=['POST'])
def classify():
    # Get the uploaded image from the request
    image = request.files['image'].read()
    image = Image.open(io.BytesIO(image))
    
    # Preprocess the image
    img = preprocess_image(image)
    
    # Perform classification using the loaded model
    result = model.predict(img)
    
    # Interpret the prediction result
    if result[0][0] > 0.5:
        prediction = 'Pneumonia Detected'
    else:
        prediction = 'No Pneumonia Detected'
    
    return prediction

if __name__ == '__main__':
    app.run(debug=True)
