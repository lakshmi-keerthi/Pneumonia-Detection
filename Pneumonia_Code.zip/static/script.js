document.getElementById('image-upload').addEventListener('change', function(event) {
    var image
